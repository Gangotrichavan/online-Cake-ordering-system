package com.cms.entity;

public enum CategoriesType {
	Egg,
    Eggless


}
