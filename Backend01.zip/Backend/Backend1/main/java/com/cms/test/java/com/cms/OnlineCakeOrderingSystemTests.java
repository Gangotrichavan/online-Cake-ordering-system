package com.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCakeOrderingSystemTests {

	@Test
	void contextLoads() {
	}

}
