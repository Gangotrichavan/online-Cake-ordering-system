package com.cms.repository;

public interface CurrentAdminSessionRepository {

}
